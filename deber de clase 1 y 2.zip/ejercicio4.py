import math
num1,num2,num,men=12.572, 15.4, 4, "1234"
print(math.ceil(num1),"\t",type(men))
# funciones de cadenas
mensaje = "hola" +"mundo" + "pyton"
men1=mensaje.split()
men2=" ".join(men1)
print(mensaje[0],mensaje[0:4],men1,men2)
print(mensaje.find("mundo"),mensaje.lower())
#funciones de fecha
from detetime import detetime,timede