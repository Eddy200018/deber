class For:
    def __init__(self,lim=4):
        self.n=lim
    
    def usoFor(self):
       nombre = "Eddy"
       datos=["Eddy",20,True]
       numeros=(2,5,6,4,1)
       docente = {"nombre": "Eddy","edad":20,"fac": "faci"}
       listanotas = [(30,40),(20,40,50),(50,40)]
       listaalumnos = [{"nombre":"juan","fianl":70},{"nombre":"Yady","fianl":60},{"nombre":"Danny","fianl":90}] 
       long = len(nombre)
       for pos in range(long):
           print(nombre[pos],end= " ")
           
bucle1 = For()
bucle1.usoFor()