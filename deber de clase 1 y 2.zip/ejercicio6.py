#__init__ Metodo constructor se ejecuta cuando se instancia la clase cuyo objetivo es crear 
# e inicializar los atributos de la clase. self es un objeto que representa la clase creando
def __init__(self,dato="instancia de la clase"):
    self,frase=dato
    
def usoVariables(self):
    edad, __peso = 20, 50.5
    nombres = "Eddy Garcia"
    tipo_sexo = "M"
    civil = true 
    print("civil={} y su tipo es:{}".format(civil,type(civil)))
    
def mostrar(self):
    print("mostrar")
    print(self.frase)
        
ejer1 = sintaxis() #instancia la clase y se crea el objetivo con todos los atributos y metodos
ejer1.usoVariables()
print(ejer1.frase)
ejer1.mostrar()       