class ciclo:
    
    def __init__(self,numero=10):
        self.numero=numero
        
    def usowhile(self):
        caracter=""
        while caracter not in("a","b","c","d","e","f","g","h","i","j","k","l","m","n","ñ","o","p","q","r","s","t","u","v","w","x","y","z"):  
            caracter = input("ingrese el alfabeto: ")
            caracter = caracter.lower()
        print("felicitaciones el caracter:{} es un alfabeto",format(caracter))
        
        
        
        
ciclo1 = ciclo()
ciclo1.usowhile()            