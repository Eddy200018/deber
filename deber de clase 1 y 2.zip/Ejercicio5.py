"""num=18
num="20"
if type(num)==int:
    num = num*2
else:    
    print("el valor no es numerico")
    
def mensaje(msg):
    print("msg")

mensaje("bienvenido a python")        
mensaje2("mi primer programa")"""