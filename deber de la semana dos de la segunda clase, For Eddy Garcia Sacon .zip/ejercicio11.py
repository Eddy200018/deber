class For:
    def __init__(self):
        self.numero=0
    
    def usoFor(self):
       nombre = "Eddy"
       datos=["Eddy",20,True]
       numeros=(2,5,6,4,1)
       docente = {"nombre": "Eddy","edad":20,"fac": "faci"}
       listanotas = [(30,40),(20,40,50),(50,40)]
       listaalumnos = [{"nombre":"juan","fianl":70},{"nombre":"Yady","fianl":60},{"nombre":"Danny","fianl":90}] 
    #    for i in range(5):
    #        print("i={}".format(i))   
       for i in range(2,5):
           print("i={}".format(i))  
       for i in range(10,2,-2):
           print("i={}".format(i))  
bucle = For()
bucle.usoFor()
# print(bucle.nombre)    