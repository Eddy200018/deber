x = int(input("ingresa un numero entero:"))
if x<1:
 x=1
    print("negativo cambiado a cero")
elif x==1:
        print("uno")
elif x==2:
    print("dos")
 else:
 print("ninguna opcion")
print("ok")if type(x)==int else print("-")